# Stats-Navigator
Google Chrome Extension to easily switch between Fangraphs.com, Baseball-Reference.com, Baseball Savant, and Baseball Prospectus
